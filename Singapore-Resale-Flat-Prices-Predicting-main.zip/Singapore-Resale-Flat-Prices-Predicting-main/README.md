# GUVI_CAPSTONE_PROJECT_Singapore-Resale-Flat-Prices-Predicting
Singapore-Resale-Flat-Prices-Predicting

objective:
   This project aims to develop and deploy a machine learning model that predicts the resale prices of flats in Singapore. The model will use historical data of resale flat transactions as the input, and output the estimated resale value of a flat. The model will be integrated into a user-friendly web application that can assist both potential buyers and sellers in making informed decisions about the resale market.


